package com.example.genikapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Button garlic_yes,garlic_no,pushup_yes,pushup_no,smoking_yes,smoking_no,alcohol_yes,alcohol_no,stress_yes,stress_no,submit,gs_yes,gs_no;
    int score=0;
    public static ArrayList <String> list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        garlic_yes=findViewById(R.id.garlic_yes);
        garlic_no=findViewById(R.id.garlic_no);
        pushup_yes=findViewById(R.id.pushup_yes);
        pushup_no=findViewById(R.id.pushup_no);
        smoking_yes=findViewById(R.id.smoking_yes);
        smoking_no=findViewById(R.id.smoking_no);
        alcohol_yes=findViewById(R.id.alcohol_yes);
        alcohol_no=findViewById(R.id.alcohol_no);
        stress_yes=findViewById(R.id.stress_yes);
        stress_no=findViewById(R.id.stress_no);
        gs_yes=findViewById(R.id.gs_yes);
        gs_no=findViewById(R.id.gs_no);
        submit=findViewById(R.id.submit);
        list=new ArrayList<>();

        garlic_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                score+=1;
            }
        });
        garlic_no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                score=score;
                list.add("Garlic is good for Cancer");
            }
        });
        pushup_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                score+=1;
            }
        });
        pushup_no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                score=score;
                list.add("Regular Exercise makes you fit");
            }
        });
        alcohol_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                score+=1;

            }
        });
        alcohol_no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                score=score;
                list.add("Alcohol is injurious to health");
            }
        });
        stress_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                score+=1;

            }
        });
        stress_no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                score=score;
                list.add("Do yoga and meditation");
            }
        });
        smoking_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                score+=1;

            }
        });
        smoking_no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                score=score;
                list.add("Smoking causes Cancer");
            }
        });
        gs_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                score+=1;
            }
        });
        gs_no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                score=score;
                list.add("Wear mask");
            }
        });
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,Activity2.class);
                intent.putExtra("SCORE",score);
                startActivity(intent);
            }
        });
    }
}